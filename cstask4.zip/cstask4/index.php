<?php
// index.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cinema Form</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');
        body {
            font-family: 'Poppins', Arial, sans-serif;
            background: linear-gradient(to right, #1c92d2, #f2fcfe);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #2c3e50;
        }
        .form-container {
            background: #ffffff;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        .form-container h1 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: #3498db;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.1);
        }
        .form-container label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            text-align: left;
        }
        .form-container input,
        .form-container select,
        .form-container button {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            outline: none;
            transition: all 0.3s ease;
        }
        .form-container input:focus,
        .form-container select:focus {
            border-color: #3498db;
            box-shadow: 0 0 8px rgba(52, 152, 219, 0.3);
        }
        .form-container button {
            background-color: #3498db;
            color: #fff;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .form-container button:hover {
            background-color: #2980b9;
        }
        .form-container select {
            appearance: none;
            background: #fff url('data:image/svg+xml;charset=US-ASCII,%3Csvg xmlns%3D%22http%3A//www.w3.org/2000/svg%22 viewBox%3D%220 0 4 5%22%3E%3Cpath fill%3D%22%233498db%22 d%3D%22M2 0L0 2h4zm0 5L0 3h4z%22/%3E%3C/svg%3E') no-repeat right 12px center;
            background-size: 12px;
            padding-right: 40px;
        }
    </style>
    <script>
        function validateForm() {
            const name = document.getElementById('name').value;
            const age = document.getElementById('age').value;
            const genre = document.getElementById('genre').value;
            const movie = document.getElementById('movie').value;

            if (!name || !age || !genre || !movie) {
                alert('Please fill out all fields.');
                return false;
            }

            if (isNaN(age) || age <= 0) {
                alert('Please enter a valid age.');
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
    <div class="form-container">
        <h1>Cinema Form</h1>
        <form action="dashboard.php" method="POST" onsubmit="return validateForm()">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" placeholder="Enter your name">

            <label for="age">Age</label>
            <input type="number" id="age" name="age" placeholder="Enter your age">

            <label for="genre">Favorite Genre</label>
            <select id="genre" name="genre">
                <option value="">Select a genre</option>
                <option value="Action">Action</option>
                <option value="Comedy">Comedy</option>
                <option value="Drama">Drama</option>
                <option value="Horror">Horror</option>
            </select>

            <label for="movie">Favorite Movie</label>
            <input type="text" id="movie" name="movie" placeholder="Enter your favorite movie">

            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>

<?php
// dashboard.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $age = intval($_POST['age']);
    $genre = htmlspecialchars($_POST['genre']);
    $movie = htmlspecialchars($_POST['movie']);

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'cinema_reviews');

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $stmt = $conn->prepare('INSERT INTO submissions (name, age, genre, movie) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('siss', $name, $age, $genre, $movie);

    if ($stmt->execute()) {
        echo '<h1 style="text-align:center; color:#3498db;">Thank you for your cooperation!</h1>';
        echo '<p style="text-align:center; color:#2c3e50;">Your data has been successfully submitted.</p>';
    } else {
        echo '<h1 style="text-align:center; color:#e74c3c;">Error</h1>';
        echo '<p style="text-align:center; color:#2c3e50;">There was a problem submitting your data.</p>';
    }

    $stmt->close();
    $conn->close();
}
?>
