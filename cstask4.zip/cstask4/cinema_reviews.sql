CREATE DATABASE cinema_reviews;

DELETE cinema_reviews;

CREATE TABLE submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    age INT,
    genre VARCHAR(50),
    movie VARCHAR(100)
);
