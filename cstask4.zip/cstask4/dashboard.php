<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $age = intval($_POST['age']);
    $genre = htmlspecialchars($_POST['genre']);
    $movie = htmlspecialchars($_POST['movie']);

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'cinema_reviews');

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $stmt = $conn->prepare('INSERT INTO submissions (name, age, genre, movie) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('siss', $name, $age, $genre, $movie);

    if ($stmt->execute()) {
        echo '<h1 style="text-align:center; color:#3498db;">Thank you for your cooperation!</h1>';
        echo '<p style="text-align:center; color:#2c3e50;">Your data has been successfully submitted.</p>';
    } else {
        echo '<h1 style="text-align:center; color:#e74c3c;">Error</h1>';
        echo '<p style="text-align:center; color:#2c3e50;">There was a problem submitting your data.</p>';
    }

    $stmt->close();
    $conn->close();
}
?>
